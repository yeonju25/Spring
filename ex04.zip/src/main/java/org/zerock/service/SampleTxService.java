package org.zerock.service;

import org.springframework.stereotype.Service;


public interface SampleTxService {

	public void addData(String value);
}
